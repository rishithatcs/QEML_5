package com.epam.campus.hooks.ui;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Hooks {
    public static WebDriver driver;
    @Before
    public void setUp(){
        driver=new EdgeDriver();
    }

    @After
    public void tearDown(){
        driver.quit();
    }
}
