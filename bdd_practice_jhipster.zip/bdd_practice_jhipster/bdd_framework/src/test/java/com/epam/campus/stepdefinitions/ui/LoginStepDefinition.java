package com.epam.campus.stepdefinitions.ui;

import com.epam.campus.hooks.ui.Hooks;
import com.epam.campus.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class LoginStepDefinition {

    LoginPage loginPage;
    WebDriver driver=Hooks.driver;

    @Given("User is on login page")
    public void userOnLoginPage(){
        loginPage=new LoginPage(driver);
        loginPage.navigateToPage();
    }

    @When("User enters username as {string} and password as {string}")
    public void userEntersCredentials(String name,String pass){
        loginPage.login(name,pass);

    }
    @Then("User should be navigated to {string}")
    public void loginResult(String expectedResult){
        if(expectedResult.equals("home")) {
            Assert.assertEquals(loginPage.isOnHomePage(), "This is your homepage");
        }
        else
            Assert.assertEquals(loginPage.isErrorDisplayed(),"Failed to sign in!");
    }

}
