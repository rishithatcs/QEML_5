package com.epam.campus.stepdefinitions.ui;

import com.epam.campus.hooks.ui.Hooks;
import com.epam.campus.pages.BankAccountPage;
import com.epam.campus.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.List;

public class BankAccountStep {
    LoginPage loginPage;
    BankAccountPage bankAccountPage;
    WebDriver driver= Hooks.driver;

    @Given("User should login with credentials {string} and {string}")
    public void userLogIn(String username,String pass){
        loginPage=new LoginPage(driver);
        loginPage.navigateToPage();
        loginPage.login(username,pass);
        Assert.assertEquals(loginPage.isOnHomePage(), "This is your homepage");
    }

    @Given("User is on background page")
    public void userIsOnBankAccountPage() throws InterruptedException {
        bankAccountPage=new BankAccountPage(driver);
        Thread.sleep(3000);
        bankAccountPage.navigateToPage();

    }
    @When("User clicks on create a new bank account and enters name as {string} and balance as {int}")
    public void userCreatesNewAccount(String name,int balance) throws InterruptedException {
        bankAccountPage.createAccount(name,balance);
        Thread.sleep(3000);
    }
    @Then("A new account with username as {string} is created")
    public void validateAccCreation(String name){
        List<String> result = bankAccountPage.validateUser(name);
        Assert.assertTrue(result.contains(name));
    }
}
