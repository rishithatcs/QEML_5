package com.epam.campus.hooks.api;

import com.epam.campus.base.BaseClass;
import io.cucumber.java.Before;

public class ApiHooks {
    @Before
    public void setup() {
        BaseClass.init(); // initialize token + request spec
    }
}
