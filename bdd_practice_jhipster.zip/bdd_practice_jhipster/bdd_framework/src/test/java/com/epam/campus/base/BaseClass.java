package com.epam.campus.base;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import io.restassured.response.Response;
import com.epam.campus.utils.ConfigReader;

public class BaseClass {
        public static String token;
        public static RequestSpecification requestSpec;

        public static void init() {
                // Get base URL
                RestAssured.baseURI = ConfigReader.getProperty("base.url");

                // Generate token
                String loginPayload = String.format("{\"username\":\"%s\",\"password\":\"%s\"}",
                        ConfigReader.getProperty("username"),
                        ConfigReader.getProperty("password"));

                Response res = given()
                        .header("Content-Type", "application/json")
                        .body(loginPayload)
                        .post("/api/authenticate");

                res.then().statusCode(200).body("id_token", notNullValue());
                token = res.jsonPath().getString("id_token");

                // Common RequestSpec
                requestSpec = given()
                        .header("Authorization", "Bearer " + token)
                        .header("Content-Type", "application/json");
        }
}
