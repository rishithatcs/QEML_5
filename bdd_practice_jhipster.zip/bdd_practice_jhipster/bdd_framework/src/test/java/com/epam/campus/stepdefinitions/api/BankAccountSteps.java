package com.epam.campus.stepdefinitions.api;

import com.epam.campus.base.BaseClass;
import com.epam.campus.pojo.BankAccount;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class BankAccountSteps {

        private String token;
        private Response response;

        @Given("I have a valid token")
        public void i_have_a_valid_token() {
            String credentials = """
                {
                  "username": "admin",
                  "password": "admin",
                  "rememberMe": false
                }
                """;

            token = given()
                    .contentType("application/json")
                    .body(credentials)
                    .post("http://localhost:9000/api/authenticate")
                    .then()
                    .extract()
                    .path("id_token");
        }

        @When("I GET the bank accounts")
        public void i_get_the_bank_accounts() {
            response = given()
                    .header("Authorization", "Bearer " + token)
                    .get("http://localhost:9000/api/bank-accounts");
        }

        @Then("the response code should be {int}")
        public void the_response_code_should_be(Integer statusCode) {
            response.then().statusCode(statusCode);
        }

        @And("I should receive a list of bank accounts")
        public void i_should_receive_list() {
            response.then().body("size()", greaterThan(0));
        }
    }


