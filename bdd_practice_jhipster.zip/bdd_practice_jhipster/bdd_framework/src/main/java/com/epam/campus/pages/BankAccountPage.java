package com.epam.campus.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

public class BankAccountPage {
    WebDriver driver;

    public BankAccountPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="//span[text()='Create a new Bank Account']")
    WebElement createAccount;

    @FindBy(xpath="//input[@id='field_name' and @name='name']")
    WebElement nameField;

    @FindBy(xpath="//input[@id='field_balance' and @name='balance']")
    WebElement balanceField;

    @FindBy(id="save-entity")
    WebElement saveButton;

    @FindBy(xpath="//tr[@data-cy='entityTable']/td")
    List<WebElement> listOfUsers;

    @FindBy(xpath="//a[@id='entity-menu']")
    WebElement entityDropDown;

    @FindBy(xpath="//span[text()='Bank Account']")
    WebElement bankAccOption;

    public void createAccount(String name,int balance) throws InterruptedException {
        createAccount.click();
        nameField.sendKeys(name);
        balanceField.sendKeys(String.valueOf(balance));
        saveButton.click();
        Thread.sleep(3000);
    }

    public List<String> validateUser(String username){
        List<String> usersList=new ArrayList<>();
       for(WebElement user:listOfUsers){
           usersList.add(user.getText());
       }
//       for(String user:usersList){
////           if(user.equals(username))
////               return user;
//           System.out.println(user);
//       }

       return usersList;
    }

    public void navigateToPage() throws InterruptedException {
        entityDropDown.click();
        bankAccOption.click();
        Thread.sleep(3000);
    }
}
