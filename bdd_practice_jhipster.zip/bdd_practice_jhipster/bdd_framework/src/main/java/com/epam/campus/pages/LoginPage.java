package com.epam.campus.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {
    WebDriver driver;
    public LoginPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(id="username")
    WebElement userName;
    @FindBy(id="password")
    WebElement password;
    @FindBy(xpath="//button[@class='btn btn-primary']")
    WebElement signIn;

    @FindBy(xpath="//p[text()='This is your homepage']")
    WebElement successMessage;

    @FindBy(xpath = "//div/strong[text()='Failed to sign in!']")
    WebElement errorMessage;

    public void login(String username,String pass) {
        userName.sendKeys(username);
        password.sendKeys(pass);
        signIn.click();
    }

    public void navigateToPage(){
        driver.get("http://localhost:9000/login");
    }

    public String isOnHomePage() {
        WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOf(successMessage)).getText();
    }

    public String isErrorDisplayed() {
        WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOf(errorMessage)).getText();
    }

}
